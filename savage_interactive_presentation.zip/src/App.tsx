// React is used implicitly for JSX
import Header from './components/Header';
import ComparisonSection from './components/ComparisonSection';
import ComparisonItem from './components/ComparisonItem';
import FeatureCard from './components/FeatureCard';
import QRCodeSection from './components/QRCodeSection';
import AccreditationSection from './components/AccreditationSection';
import ProductComparison from './components/ProductComparison';
import './App.css';

function App() {
  // Product comparison data
  const savageProducts = [
    {
      name: "Ring Shank Galvanized Nails",
      description: "Superior quality nails for better hold and durability"
    },
    {
      name: "SealoronXT Deck Tape",
      description: "Premium protection against water infiltration"
    },
    {
      name: "SealoronXT Peel-and-Stick Membrane",
      description: "Advanced waterproofing technology"
    },
    {
      name: "Velora ONE Roof Underlayment",
      description: "15lb grade premium underlayment for superior protection"
    },
    {
      name: "Metal Rake & Drip Edge Installation",
      description: "Double the size of standard drip edge for better protection"
    }
  ];

  const otherProducts = [
    {
      name: "Standard Roofing Nails",
      description: "Basic nails with less holding power"
    },
    {
      name: "No Seal/Deck Taping",
      description: "Missing critical waterproofing layer"
    },
    {
      name: "Basic Underlayment",
      description: "Only 7lb-10lb grade compared to our 15lb grade"
    },
    {
      name: "Standard Drip Edge",
      description: "Half the size of our premium drip edge"
    },
    {
      name: "Cobra or Turtle Venting",
      description: "Instead of upgraded Ridge Vent that we provide"
    }
  ];

  // Service comparison data
  const serviceComparisons = [
    {
      savageFeature: "On-Site Project manager that will be there the whole time!",
      otherFeature: "Usually have runner for materials but not a Project Manager"
    },
    {
      savageFeature: "Property Protected with tarping and securing all areas from damage",
      otherFeature: "May not tarp and secure all areas from damage"
    },
    {
      savageFeature: "On site communication with pictures throughout the process",
      otherFeature: "Limited communication during construction"
    },
    {
      savageFeature: "Superior Clean up after project completion",
      otherFeature: "Basic cleanup that may leave debris"
    },
    {
      savageFeature: "Drone Imaging throughout the build to ensure safety and quality",
      otherFeature: "Drones are used for inspection only, not during construction"
    },
    {
      savageFeature: "Superior Communication throughout the entire process",
      otherFeature: "Limited updates and communication"
    }
  ];

  // Company features
  const companyFeatures = [
    {
      title: "Established Local Business",
      description: "Established in 2017. Owner Danny has been in the construction industry since 2002. His philosophy is to treat every home like it was their own.",
      isHighlighted: true
    },
    {
      title: "Physical Location",
      description: "At Savage Roofing, we warmly invite you to visit our location during business hours to meet our amazing staff! Our team is dedicated to keeping you informed throughout the entire process.",
      isHighlighted: true
    },
    {
      title: "Community Involvement",
      description: "At Savage Roofing, we are passionate about giving back to our community. Whether it's assisting at the food pantry or supporting local youth sports through donations, we are dedicated to making a difference.",
      isHighlighted: true
    },
    {
      title: "Other Companies",
      description: "Other companies claim to have been in the community since 1960 or over 100 years, but do not give specifics on what they have been doing. Most roofing companies typically either do not have a physical storefront, are not local if they do, or run their operations from home.",
      isHighlighted: false
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="bg-red-600 text-white p-6 rounded-lg mb-8 text-center">
          <h1 className="text-3xl font-bold mb-2">SAVAGE Comparison Guide</h1>
          <p className="text-xl">Protecting Your Home Like Our Own</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {companyFeatures.map((feature, index) => (
            <FeatureCard 
              key={index}
              title={feature.title}
              description={feature.description}
              isHighlighted={feature.isHighlighted}
            />
          ))}
        </div>
        
        <AccreditationSection 
          title="Google Reviews and Accreditations" 
          reviewCount="700"
        />
        
        <ComparisonSection title="Our Products Vs. Theirs">
          <ProductComparison 
            savageProducts={savageProducts}
            otherProducts={otherProducts}
          />
        </ComparisonSection>
        
        <ComparisonSection title="Protecting Your Home Like Our Own">
          <div className="space-y-4">
            {serviceComparisons.map((comparison, index) => (
              <ComparisonItem 
                key={index}
                savageFeature={comparison.savageFeature}
                otherFeature={comparison.otherFeature}
              />
            ))}
          </div>
        </ComparisonSection>
        
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <QRCodeSection 
            title="Scan the code and save!"
            subtitle="Connect with us today"
          />
          
          <div className="bg-white rounded-lg shadow-lg p-6 flex flex-col justify-center items-center">
            <h2 className="text-2xl font-bold mb-4 text-red-600">OVER 700 Google Reviews!</h2>
            <p className="text-lg mb-2">Thank you for trusting us with your home</p>
            <p className="text-xl font-bold mt-4">**Referrals = Savage Cash**</p>
          </div>
        </div>
      </main>
      
      <footer className="bg-gray-800 text-white py-6 px-4 text-center">
        <p>© {new Date().getFullYear()} Savage Roofing. All rights reserved.</p>
        <p className="mt-2">Protecting Your Home Like Our Own</p>
      </footer>
    </div>
  );
}

export default App;

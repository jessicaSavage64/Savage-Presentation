import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-blue-600 text-white py-4 px-6 flex justify-between items-center">
      <div className="flex items-center">
        <h1 className="text-2xl font-bold">SAVAGE Comparison Guide</h1>
      </div>
      <div>
        <button className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded transition-all">
          Contact Us
        </button>
      </div>
    </header>
  );
};

export default Header;

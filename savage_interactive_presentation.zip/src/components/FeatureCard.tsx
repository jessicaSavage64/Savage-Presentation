import React from 'react';

interface FeatureCardProps {
  title: string;
  description: string;
  icon?: string;
  isHighlighted?: boolean;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ 
  title, 
  description, 
  icon, 
  isHighlighted = false 
}) => {
  return (
    <div 
      className={`p-5 rounded-lg transition-all duration-300 hover:shadow-lg ${
        isHighlighted 
          ? 'bg-red-50 border-l-4 border-red-500' 
          : 'bg-white border border-gray-200'
      }`}
    >
      <div className="flex items-center mb-3">
        {icon && <span className="text-2xl mr-2">{icon}</span>}
        <h3 className="text-lg font-bold">{title}</h3>
      </div>
      <p className="text-gray-700">{description}</p>
    </div>
  );
};

export default FeatureCard;

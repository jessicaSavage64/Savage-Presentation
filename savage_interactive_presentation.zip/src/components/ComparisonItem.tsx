import React, { useState } from 'react';

interface ComparisonItemProps {
  savageFeature: string;
  otherFeature: string;
  icon?: string;
}

const ComparisonItem: React.FC<ComparisonItemProps> = ({ savageFeature, otherFeature, icon }) => {
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <div 
      className="grid grid-cols-2 gap-4 mb-4 p-4 rounded-lg transition-all duration-300"
      style={{ 
        backgroundColor: isHovered ? '#f0f9ff' : 'white',
        boxShadow: isHovered ? '0 4px 12px rgba(0,0,0,0.1)' : '0 1px 3px rgba(0,0,0,0.05)'
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="bg-red-50 p-4 rounded-lg border-l-4 border-red-500">
        <div className="flex items-start">
          {icon && <span className="mr-2 text-red-500">{icon}</span>}
          <p className="font-medium">{savageFeature}</p>
        </div>
      </div>
      <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-gray-400">
        <p className="text-gray-700">{otherFeature}</p>
      </div>
    </div>
  );
};

export default ComparisonItem;

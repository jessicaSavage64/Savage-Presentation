import React from 'react';

interface AccreditationSectionProps {
  title: string;
  reviewCount: string;
  accreditationLogos?: string[];
}

const AccreditationSection: React.FC<AccreditationSectionProps> = ({ 
  title, 
  reviewCount,
  accreditationLogos = []
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-8">
      <h2 className="text-xl font-bold text-center mb-4">{title}</h2>
      
      <div className="bg-yellow-50 p-4 rounded-lg mb-4 text-center">
        <p className="text-lg font-bold">OVER {reviewCount} Google Reviews!</p>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
        {accreditationLogos.length > 0 ? (
          accreditationLogos.map((logo, index) => (
            <div key={index} className="flex justify-center">
              <img 
                src={logo} 
                alt={`Accreditation ${index + 1}`} 
                className="h-12 object-contain"
              />
            </div>
          ))
        ) : (
          Array(4).fill(0).map((_, index) => (
            <div key={index} className="bg-gray-100 h-12 rounded flex items-center justify-center">
              <span className="text-gray-400 text-xs">Logo Placeholder</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AccreditationSection;

import React from 'react';

interface ProductComparisonProps {
  savageProducts: {
    name: string;
    description: string;
    image?: string;
  }[];
  otherProducts: {
    name: string;
    description: string;
    image?: string;
  }[];
}

const ProductComparison: React.FC<ProductComparisonProps> = ({ 
  savageProducts, 
  otherProducts 
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-8">
      <h2 className="text-xl font-bold text-center mb-6">Our Products Vs. Theirs</h2>
      
      <div className="grid grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-bold text-red-600 mb-4 text-center">Savage Roofing</h3>
          <div className="space-y-4">
            {savageProducts.map((product, index) => (
              <div key={index} className="bg-red-50 p-4 rounded-lg border-l-4 border-red-500">
                <h4 className="font-bold mb-2">{product.name}</h4>
                <p className="text-sm">{product.description}</p>
                {product.image && (
                  <div className="mt-2">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-auto rounded"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-bold text-gray-600 mb-4 text-center">Other Companies</h3>
          <div className="space-y-4">
            {otherProducts.map((product, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg border-l-4 border-gray-400">
                <h4 className="font-bold mb-2">{product.name}</h4>
                <p className="text-sm">{product.description}</p>
                {product.image && (
                  <div className="mt-2">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-auto rounded"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductComparison;

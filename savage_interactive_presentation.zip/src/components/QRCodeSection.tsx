import React from 'react';

interface QRCodeSectionProps {
  title: string;
  subtitle: string;
  qrImageSrc?: string;
}

const QRCodeSection: React.FC<QRCodeSectionProps> = ({ title, subtitle, qrImageSrc }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 text-center">
      <h2 className="text-2xl font-bold mb-2">{title}</h2>
      <p className="text-gray-700 mb-4">{subtitle}</p>
      
      {qrImageSrc ? (
        <div className="flex justify-center">
          <img 
            src={qrImageSrc} 
            alt="QR Code" 
            className="w-48 h-48 object-contain border-2 border-gray-200 rounded-lg"
          />
        </div>
      ) : (
        <div className="w-48 h-48 mx-auto bg-gray-200 rounded-lg flex items-center justify-center">
          <span className="text-gray-500">QR Code Placeholder</span>
        </div>
      )}
      
      <p className="mt-4 font-bold text-red-600">Scan to save!</p>
      <p className="text-sm text-gray-600 mt-2">**Referrals = Savage Cash**</p>
    </div>
  );
};

export default QRCodeSection;

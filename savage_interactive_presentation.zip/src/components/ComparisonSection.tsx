import React, { useState } from 'react';

interface ComparisonSectionProps {
  title: string;
  children: React.ReactNode;
}

const ComparisonSection: React.FC<ComparisonSectionProps> = ({ title, children }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  
  return (
    <div className="mb-8">
      <div 
        className="bg-blue-600 text-white p-4 rounded-t-lg flex justify-between items-center cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <h2 className="text-xl font-bold">{title}</h2>
        <span className="text-2xl">{isExpanded ? '−' : '+'}</span>
      </div>
      
      <div 
        className={`bg-white rounded-b-lg border border-gray-200 overflow-hidden transition-all duration-500 ${
          isExpanded ? 'max-h-[2000px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="p-4">
          {children}
        </div>
      </div>
    </div>
  );
};

export default ComparisonSection;

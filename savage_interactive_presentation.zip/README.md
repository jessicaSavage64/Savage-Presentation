# SAVAGE Comparison Guide - Interactive Presentation

This is an enhanced, interactive version of the Savage Roofing comparison guide, built with React and modern web technologies.

## Features

- Interactive comparison sections that expand/collapse when clicked
- Hover effects to highlight important information
- Professional styling with consistent branding
- Mobile-responsive design
- Animated transitions between sections

## How to Use

### Option 1: Deploy the Built Version

The `dist` folder contains a fully built version of the presentation that can be deployed to any web hosting service:

1. Upload the entire contents of the `dist` folder to your web hosting service
2. No additional configuration is needed - it's ready to use!

### Option 2: Further Customize the Source Code

If you want to make additional changes:

1. Install Node.js and npm/pnpm
2. Navigate to the project directory
3. Run `pnpm install` to install dependencies
4. Run `pnpm run dev` to start the development server
5. Make your changes in the `src` directory
6. Run `pnpm run build` to create a new production build

## Structure

- `src/components/` - Contains all the custom components
- `src/App.tsx` - Main application component with all the content
- `src/App.css` - Custom animations and styling

## Customization Tips

- To update the company information, edit the data arrays in `src/App.tsx`
- To change colors, modify the Tailwind classes (red-600 for primary color, etc.)
- To add a real QR code, update the QRCodeSection component with your image

## Contact

For any questions or additional customization needs, please contact us.
